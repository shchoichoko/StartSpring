package kr.ac.kopo.ctc.spring.board.service;

public interface BoardItemService {
	void test();
	void testAopBefore();
	void testAopAfter();
	String testAopAfterReturning();
	void testAopAfterThrowing();
	void testAopAround();

}
